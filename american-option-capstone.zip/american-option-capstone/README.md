# American Option Pricing Capstone

Comparing CRR binomial pricing, neural-network price approximation, and a
reinforcement-learning exercise policy for American put options.

**Question this project answers:** when pricing American puts, what do we
gain and lose by using a tree, a neural-network pricer, and an RL stopping
policy?

## Methods

- **CRR binomial American put pricer** — the benchmark. Backward induction
  with `max(exercise, continuation)`, also extracts the exercise boundary.
- **Neural-network pricer** — a small MLP trained on binomial-labeled
  synthetic contracts, evaluated for accuracy *and* financial sanity
  (monotonicity, intrinsic-value bound, extrapolation flags).
- **RL stopping policy (DQN)** — learns hold-vs-exercise directly in a
  simulated environment, evaluated by Monte Carlo against baseline
  policies and against the binomial exercise boundary.
- **Black-Scholes** — closed-form European reference point only; it does
  not price American early exercise.

## Repository layout

```
american-option-capstone/
  README.md
  requirements.txt
  configs/                # nn.yaml, rl.yaml — hyperparameters & seeds
  reports/
    Week9_Report.md        # final report (source; export to PDF, see below)
    figures/                # generated plots
    checkpoints/            # trained NN / DQN checkpoints (gitignored, regenerate via scripts)
  src/
    pricing/
      black_scholes.py
      binomial.py           # OptionContract, Pricer interface, CRR pricer + boundary
      payoffs.py
    data/
      synthetic_contracts.py  # shared evaluation grid + NN training data
    ml/
      models.py              # NumPyAdamMLP
      train_nn.py
      evaluate_nn.py
    rl/
      env.py                 # AmericanPutEnv (GBM) + AmericanPutLatticeEnv (CRR lattice)
      train_dqn.py
      evaluate_policy.py
    evaluation/
      metrics.py
      plots.py
      comparison.py
  tests/
    test_binomial.py
    test_payoffs.py
    test_rl_env.py
```

Where each Week's work ended up:

| Course part | Final project artifact |
|---|---|
| Weeks 1-2 | `src/pricing/payoffs.py`, `src/pricing/black_scholes.py` |
| Weeks 3-4 | `src/pricing/binomial.py` |
| Weeks 5-6 | `src/ml/models.py`, `src/ml/train_nn.py`, `src/ml/evaluate_nn.py` |
| Weeks 7-8 | `src/rl/env.py`, `src/rl/train_dqn.py`, `src/rl/evaluate_policy.py` |
| Week 9 | `src/evaluation/*`, `reports/Week9_Report.md` |

## Setup

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Reproduce results

Run these from the repo root, in order:

```bash
# 0. Sanity-check everything first
python -m pytest

# 1. Generate the shared evaluation grid (and, optionally, NN training data)
python -m src.data.synthetic_contracts --out data/contracts.csv

# 2. Train the neural-network pricer
python -m src.ml.train_nn --out reports/checkpoints/nn_pricer.pkl

# 3. Evaluate the NN pricer (accuracy + financial sanity checks)
python -m src.ml.evaluate_nn --checkpoint reports/checkpoints/nn_pricer.pkl \
    --test-data reports/checkpoints/nn_pricer_test.npz

# 4. Train the DQN stopping policy
python -m src.rl.train_dqn --episodes 10000 --out reports/checkpoints/dqn.pth

# 5. Build the unified comparison table (binomial vs NN vs RL)
python -m src.evaluation.comparison --out reports/comparison.csv \
    --nn-checkpoint reports/checkpoints/nn_pricer.pkl \
    --dqn-checkpoint reports/checkpoints/dqn.pth

# 6. Regenerate all final figures
python -m src.evaluation.plots --out reports/figures \
    --comparison-csv reports/comparison.csv \
    --dqn-checkpoint reports/checkpoints/dqn.pth
```

All seeds are fixed (`seed=42` by default; see `configs/nn.yaml` and
`configs/rl.yaml`) so results are reproducible up to hardware/library
floating-point differences.

## Tests

```bash
python -m pytest -v
```

22 tests cover payoff correctness, binomial pricing sanity (monotonicity in
spot/strike, American ≥ European, price ≥ intrinsic value, exercise
boundary extraction, invalid-input handling), and RL environment invariants
(non-negative reward, termination behavior, valid state/action bounds).

## Final report

See [`reports/Week9_Report.md`](reports/Week9_Report.md). Export to PDF with:

```bash
pandoc reports/Week9_Report.md -o reports/Week9_Report.pdf
```

(or open the Markdown in any editor that renders it, e.g. VS Code, and use
"Print to PDF").

## Limitations

This project uses synthetic contracts and a CRR binomial benchmark under
simplified assumptions. The neural network approximates that benchmark on
the sampled grid, and the RL policy is evaluated by Monte Carlo simulation
in the same stylized environment. Results should be read as a learning and
prototyping exercise, not as production trading advice or a calibrated
market-pricing system. See the report's Limitations section for details
(training-range extrapolation, DQN generalization across contract
parameters, no dividends/transaction costs/stochastic volatility, etc.).
